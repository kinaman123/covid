﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
namespace Covid_
{
    public partial class register : System.Web.UI.Page
    {
        MySqlConnection connection = new MySqlConnection("server= localhost; userid = root; password = ; database = coronaeducation");
        protected void Page_Load(object sender, EventArgs e)
        {
            PnlSignUp.Visible = false;
            Pnlmessage.Visible = false;

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            String Userid;
            String password;
            
            try
            {


                Userid = txtFname.Text.Substring(0, 1) + txtLname.Text;
                password = txtClass.Text + DplRegions.SelectedValue;

                String query = ("INSERT INTO `registration`(`FName`, `LName`, `Age`, `Gender`, `School`, `Class`, `Region`,`UserID`,`Password`) VALUES (@FName,@LName,@Age,@Gender,@School,@Class,@Region,@UserID,@Password)");
                MySqlCommand Command = new MySqlCommand(query, connection);
                Command.Parameters.Add("@FName", MySqlDbType.VarChar).Value = txtFname.Text;
                Command.Parameters.Add("@LName", MySqlDbType.VarChar).Value = txtLname.Text;
                Command.Parameters.Add("@Age", MySqlDbType.VarChar).Value = txtAge.Text;
                Command.Parameters.Add("@Gender", MySqlDbType.VarChar).Value = DplGender.SelectedValue;
                Command.Parameters.Add("@School", MySqlDbType.VarChar).Value = txtSchool.Text;
                Command.Parameters.Add("@Class", MySqlDbType.VarChar).Value = txtClass.Text;
                Command.Parameters.Add("@Region", MySqlDbType.VarChar).Value = DplRegions.SelectedValue;
                Command.Parameters.Add("@UserID", MySqlDbType.VarChar).Value = Userid;
                Command.Parameters.Add("@Password", MySqlDbType.VarChar).Value = password;

                connection.Open();
                Command.Connection = connection;
                Command.CommandText = query;
                Command.ExecuteNonQuery();


                //Response.Write("<script>alert('Your UserID is');</script>");

                Pnlmessage.Visible = true;
                Lblmessage.Text = "Your User ID is :" + " " + Userid + " " + "and Password is :" + " " + password;
            }
            catch (MySqlException ex)
            {
                ex.ErrorCode.ToString();
            }
            finally
            {
                connection.Close();
            }
        }
        

        protected void btnSingup_Click(object sender, EventArgs e)
        {
            PnlSignUp.Visible = true;
        }

        protected void BtnOK_Click(object sender, EventArgs e)
        {
            Response.Redirect("login.aspx");
        }
    }
}
