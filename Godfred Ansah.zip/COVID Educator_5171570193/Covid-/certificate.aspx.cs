﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
namespace Covid_
{
    public partial class certificate : System.Web.UI.Page
    {
        MySqlDataAdapter Da;
        MySqlDataReader Dr;
        MySqlCommand sqlCmd;
        MySqlConnection connection = new MySqlConnection("server= localhost; userid = root; password = ; database = coronaeducation");


        MySqlCommand COMMAND;
        protected void Page_Load(object sender, EventArgs e)
        {
            LblDate.Text = DateTime.Now.ToShortDateString();
            if (Session["s_username"] == null)
            {
                Response.Redirect("login.aspx");
            }

            Lblname.Text = Session["s_username"].ToString();
            Lblname.Visible = false;
            try
            {
                connection.Open();
                String Query;
                Query = "select * from registration where UserID = '" + Lblname.Text.Trim() + "'";
                sqlCmd = new MySqlCommand(Query, connection);
                Dr = sqlCmd.ExecuteReader();
                while (Dr.Read())
                {
                    txtCertname.Text = Dr.GetString("FName");
                    txtCert2.Text = Dr.GetString("LName");
                }
            }
            catch (MySqlException ex)
            {
                ex.ErrorCode.ToString();
            }
            finally
            {
                connection.Close();
            }
        }

        protected void BtnShow_Click(object sender, EventArgs e)
        {
            Response.Redirect("DataView.aspx");
        }
    }
}