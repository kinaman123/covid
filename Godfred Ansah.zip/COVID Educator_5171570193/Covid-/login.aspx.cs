﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
namespace Covid_
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Btnlogin_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection();
            String connectionString = @"server=localhost; userid = root; database = coronaeducation";
            con.ConnectionString = connectionString;
            MySqlCommand cmd;
            MySqlDataReader dr;

            try
            {
                con.Open();
                String query = "SELECT * FROM registration WHERE UserID = '" + txtUserID.Text.Trim() + "' and Password = '" + txtPassword.Text.Trim() + "' ";
                cmd = new MySqlCommand(query, con);
                dr = cmd.ExecuteReader();

                int count = 0;

                while (dr.Read())
                {
                    count = +1;


                    if (count == 1)
                    {
                        Session["s_username"] = txtUserID.Text.Trim();
                        Response.Redirect("course.aspx");

                    }
                    else if (count < 1)
                    {
                        Response.Write("<script>alert('wrong username or password')</script> ");

                    }

                }
            }
            catch (MySqlException ex)
            {
                ex.ErrorCode.ToString();
            }
            finally
            {
                con.Close();
            }
        }
    }
}