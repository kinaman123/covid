﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
namespace Covid_
{
    public partial class DataView : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            Response.Redirect("course.aspx");
        }

        protected void btnLoad_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection();
            MySqlCommand cmd = new MySqlCommand();
            con.ConnectionString = "server= localhost; userid = root; password = ; database = coronaeducation";

            con.Open();

            cmd.CommandText = "SELECT `id`, `FName`, `LName`, `Age`, `Gender`, `School`, `Class`, `Region`  FROM `registration`";
            cmd.Connection = con;

            GridView1.DataSource = cmd.ExecuteReader();
            GridView1.DataBind();
        }
    }
}